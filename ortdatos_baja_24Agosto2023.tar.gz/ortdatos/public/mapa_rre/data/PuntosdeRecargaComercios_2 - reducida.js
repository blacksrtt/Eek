var json_PuntosdeRecargaComercios_2 = {
    "type":"FeatureCollection",
    "name":"PuntosdeRecargaComercios_2",
    "crs":{
        "type":"name",
        "properties":{
            "name":"urn:ogc:def:crs:OGC:1.3:CRS84"
        }
    },
    "features":[
        {"type":"Feature",
            "properties":{
            "Dirección":"Calle de Chiapas 188,  Ciudad de Mexico",
            "Descripción":"El huacal",
            "Lunes":"11:00 a 19:00","Martes":"11:00 a 19:00","Miércoles":"11:00 a 19:00","Jueves":"11:00 a 19:00","Viernes":"11:00 a 19:00","Sábado":"11:00 a 19:00","Domingo":"12:00 a 17:00","Dia Festivo":"00:00 a 00:00"
            },
            "geometry":{
                "type":"Point",
                "coordinates":[-99.1652117,19.4118379]
            }
        },
        {"type":"Feature",
            "properties":{"Dirección":"Morelos 12, Huilango, Mex.",
            "Descripción":"El Rincón",
            "Lunes":"00:00 a 00:00",
            "Martes":"00:00 a 00:00","Miércoles":"00:00 a 00:00","Jueves":"18:00 a 23:00","Viernes":"18:00 a 23:00","Sábado":"18:00 a 23:00","Domingo":"18:00 a 23:00",
            "Dia Festivo":"00:00 a 00:00"},
            "geometry":{
                "type":"Point",
                "coordinates":[-99.24912832,19.68417799]
            }
        },
        {"type":"Feature",
            "properties":{
            "Dirección":"Misantla 2,  CDMX",
            "Descripción":"Enrico Caruso",
            "Lunes":"09:00 a 18:00",
            "Martes":"09:00 a 18:00","Miércoles":"09:00 a 18:00","Jueves":"09:00 a 18:00","Viernes":"09:00 a 18:00","Sábado":"00:00 a 00:00","Domingo":"00:00 a 00:00","Dia Festivo":"00:00 a 00:00"
            },
            "geometry":{
                "type":"Point",
                "coordinates":[-99.158485,19.4055824]
        }
    }
    ]
}