<!doctype html>
<html>
<meta http-equiv="Refresh" content="0; url='https://rupiahtoto.airporthuahinbus.com/'" />
</html>
</html>